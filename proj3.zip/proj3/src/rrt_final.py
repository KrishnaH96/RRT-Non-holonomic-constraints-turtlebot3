'''
****************************Project-3 | Phase-2*****************************

Course  : ENPM661 - Planning
Team    : Krishna Hundekari (119239049) & Shail Shah (119340547)
UIDs    : krishnah & sshah115
github link : https://github.com/sshah115/A-star-turtlebot.git

****************************************************************************
'''
# Importing required modules/libraries
import numpy as np
import cv2 as cv
import copy
from queue import PriorityQueue
import math as math
from math import dist
import matplotlib.pyplot as plt
import matplotlib.patches as patch
import time
import random

# Function to generate map with obstacles using cv functions
def genMap():

    # Generating a black background arena
    arena = np.zeros((2000,3200, 3), dtype="uint8")
    
    # Defining colors
    white = (255,255,255)
    blue = (255, 0, 0)
    orange = (0, 165, 255)

    # Drawing rectangle obstacles and image border
    # First column
    cv.rectangle(arena, (700,1625), (850,1475), blue, -1)
    cv.rectangle(arena, (700 - (obsClea//2),1625 + (obsClea//2)), (850 + (obsClea//2),1475 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (700,1075), (850,925), blue, -1)
    cv.rectangle(arena, (700 - (obsClea//2),1075 + (obsClea//2)), (850 + (obsClea//2),925 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (700,525), (850,375), blue, -1)
    cv.rectangle(arena, (700 - (obsClea//2),525 + (obsClea//2)), (850 + (obsClea//2),375 - (obsClea//2)), white, obsClea)

    # Second column
    cv.rectangle(arena, (1450,2000), (1600,1850), blue, -1)
    cv.rectangle(arena, (1450 - (obsClea//2),2000 + (obsClea//2)), (1600 + (obsClea//2),1850 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (1450,1400), (1600,1250), blue, -1)
    cv.rectangle(arena, (1450 - (obsClea//2),1400 + (obsClea//2)), (1600 + (obsClea//2),1250 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (1450,750), (1600,600), blue, -1)
    cv.rectangle(arena, (1450 - (obsClea//2),750 + (obsClea//2)), (1600 + (obsClea//2),600 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (1450,150), (1600,0), blue, -1)
    cv.rectangle(arena, (1450 - (obsClea//2),150 + (obsClea//2)), (1600 + (obsClea//2),0 - (obsClea//2)), white, obsClea)

    # Third column
    cv.rectangle(arena, (2200,1625), (2350,1475), blue, -1)
    cv.rectangle(arena, (2200 - (obsClea//2),1625 + (obsClea//2)), (2350 + (obsClea//2),1475 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (2200,1075), (2350,925), blue, -1)
    cv.rectangle(arena, (2200 - (obsClea//2),1075 + (obsClea//2)), (2350 + (obsClea//2),925 - (obsClea//2)), white, obsClea)
    cv.rectangle(arena, (2200,525), (2350,375), blue, -1)
    cv.rectangle(arena, (2200 - (obsClea//2),525 + (obsClea//2)), (2350 + (obsClea//2),375 - (obsClea//2)), white, obsClea)

    cv.rectangle(arena, (0, 0), (3200, 2000), white, obsClea*2)
  
    return cv.resize(arena, (int(3200/scaleFac),int(2000/scaleFac)))

def obstacle_check(node_c):

    node = copy.deepcopy(node_c)

    xPt = int(node[0]/scaleFac)

    yPt = int((2000 - node[1])/scaleFac)

    if yPt < int(2000/scaleFac) and xPt < int(3200/scaleFac):

        # print(f"The pixel value of coordinate {(node[0], node[1])} is: ", canvas[yPt, xPt])

        if canvas[yPt, xPt][0] == 0 and canvas[yPt, xPt][1] == 0 and canvas[yPt, xPt][2] == 0:
            status = False
        elif canvas[yPt, xPt][0] == 255 and canvas[yPt, xPt][1] == 255 and canvas[yPt, xPt][2] == 255:
            status = True
        else:
            status = True   

    else:
        status = True 
        print("Out of arena")

    return status

def round_thresh(val):

    if val % thresh_for_grid != 0:
        val = np.round(val/thresh_for_grid)*thresh_for_grid
    return val

compare_with_this = 100    

def check_goal(current):
    
    dt = dist((current[0], current[1]), (goal_x, goal_y))   
          
    if dt < compare_with_this:
        return True
    else:
        return False
    
def genRandomNode():

    global random_node_list
    global goal_pose

    node_found = False 

    counter = 0
    while not node_found and counter < 5:

        if random.randint(0, 100) > 50:
            found = False

            while(not found):
                x_coordinate = random.uniform(x_min, x_max)
                y_coordinate = random.uniform(y_min, y_max)

                # print((x_coordinate, y_coordinate))

                if not obstacle_check((x_coordinate, y_coordinate)):
                    random_node = (x_coordinate,y_coordinate)
                    found = True
        
            node_found = not any(dist((random_node[0], random_node[1]), (n[0], n[1])) <= 100 for n in random_node_list)  
        
        else:
            random_node = goal_pose
            return random_node
     
        counter += 1

    if counter >= 5:
        random_node = goal_pose
        return random_node
        
    return random_node


def proximity(node):

    global node_in_tree

    node_in_action = copy.deepcopy(node)
    
    Xn=node_in_action[0]
    Yn=node_in_action[1]

    return not any(dist((Xn, Yn), (n[0], n[1])) <= 100 for n in node_in_tree)

def child_explored(node, UL,UR):

    # print("Generating a child")

    global current_child_list

    # global wasted_count

    node_in_action = copy.deepcopy(node)
    
    current_parent = node_in_action

    clnVis = []

    #lets calculate cost part and check if the path comes in obstacle
    t = 0
    r = 33
    L = 160
    dt = 0.1
    Xn=current_parent[0]
    Yn=current_parent[1]
    clnVis.append((Xn,Yn))
    Thetan = 3.14 * current_parent[2] / 180

    D=0

    while t<1:

        t = t + dt
        Xs = Xn
        Ys = Yn
        Delta_Xn = 0.5*r * (UL + UR) * math.cos(Thetan) * dt
        Delta_Yn = 0.5*r * (UL + UR) * math.sin(Thetan) * dt
        Thetan += (r / L) * (UR - UL) * dt
        D=D+ math.sqrt(math.pow((0.5*r * (UL + UR) * math.cos(Thetan) * dt),2)+math.pow((0.5*r * (UL + UR) * math.sin(Thetan) * dt),2))

        if obstacle_check((Xn, Yn)):
            return None

        Xn = Xn + Delta_Xn
        Yn = Yn + Delta_Yn

        clnVis.append((Xn, Yn))

    Thetan = (180 * (Thetan) / np.pi) % 360

    updated_x =  Xn
    updated_y = Yn
    updated_theta = Thetan  

    current_child = (updated_x, updated_y, updated_theta)

    if current_child not in node_in_tree:
        if proximity(current_child):
            for pt in range(len(clnVis)-1):
                        plt.plot((clnVis[pt][0], clnVis[pt + 1][0]),(clnVis[pt][1], clnVis[pt + 1][1]), color="blue")
                        if pt % 144*12 == 0:
                            plt.pause(0.0001)

            return (current_child, (UL,UR))

def getClosestNode(randnode):

    random_node = copy.deepcopy(randnode)

    global node_in_tree

    dist_from_node = []

    #find the closest child to this random node
    for n in node_in_tree:
        dist_from_node.append(dist((random_node[0], random_node[1]), (n[0], n[1])))

    # sort the node_in_tree list based on distance from random node
    node_in_tree_sorted = [x for _, x in sorted(zip(dist_from_node, node_in_tree))]

    return node_in_tree_sorted[:10]

scaleFac = 1
thresh_for_grid = 1
thresh = 1

obstacle_real= int(round_thresh(float(input("\nEnter obstacle clearance: \n"))))
radius_robot = 105
obsClea = obstacle_real  + radius_robot

canvas = genMap()

#Getting home position
home_x = round_thresh(float(input("Hey!! Where to start? Please enter home 'x' coordinate:  \n")))
home_y = round_thresh(float(input("\nPlease enter home 'y' coordinate: \n")))
# home_x+= 0
# home_y+= 1000
home_loc = (home_x, home_y)
while obstacle_check(home_loc):
    print("\nThe entered value is in the obstacle. Please enter new values\n")
    home_x = round_thresh(float(input("\nHey!! Where to start? Please enter home 'x' coordinate:  \n")))
    home_y = round_thresh(float(input("\nPlease enter home 'y' coordinate: \n")))
    home_loc = (home_x, home_y)
home_theta = int(input("\nGive home orientation:  \n"))

print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")

# Getting Goal Position

goal_x= round_thresh(float(input("\nNow give the goal 'x' coordinate \n")))
goal_y = round_thresh(float(input("\nNow give the goal 'y' coordinate \n")))
# goal_x += 0
# goal_y += 1000
goal_loc = (goal_x, goal_y)
while obstacle_check(goal_loc):
    print("\nThe entered value is in the obstacle. Please enter new values\n")
    goal_x= round_thresh(float(input("\nNow give the goal 'x' coordinate \n")))
    goal_y = round_thresh(float(input("\nNow give the goal 'y' coordinate \n")))
    goal_loc = (goal_x, goal_y)
    
rpm_1 = round_thresh(float(input("\nEnter first possible RPM for the wheel: \n")))

print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")  

rpm_2 = round_thresh(float(input("\nEnter second possible RPM  for the wheel: \n")))

print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")


x_visited = [] 
y_visited = []
random_node_list = []

x_min = 0
y_min = 0
x_max = 3200
y_max= 2000

fig, ax = plt.subplots(figsize=(6,2.5))

# First Column
firstColZero = patch.Rectangle((700,1475), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
firstColOne = patch.Rectangle((700,925), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
firstColTwo = patch.Rectangle((700,375), 150, 150, linewidth=1, edgecolor='g', facecolor='g')

# Second Column
secColOne = patch.Rectangle((1450,1850), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
secColTwo = patch.Rectangle((1450,1250), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
secColThree = patch.Rectangle((1450,600), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
secColFour = patch.Rectangle((1450,0), 150, 150, linewidth=1, edgecolor='g', facecolor='g')

# Third Column
thirdColZero = patch.Rectangle((2200,1475), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
thirdColOne = patch.Rectangle((2200,925), 150, 150, linewidth=1, edgecolor='g', facecolor='g')
thirdColTwo = patch.Rectangle((2200,375), 150, 150, linewidth=1, edgecolor='g', facecolor='g')

start_circle = patch.Circle((home_x,home_y), 20, linewidth=1, edgecolor='r', facecolor='r')
goal_circle = patch.Circle((goal_x,goal_y), 20, linewidth=1, edgecolor='r', facecolor='r')
# end_circle = patch.Circle((goal_x,goal_y), compare_with_this/2, linewidth=1, edgecolor='r', facecolor='None')

ax.add_patch(firstColZero)
ax.add_patch(firstColOne)
ax.add_patch(firstColTwo)
ax.add_patch(secColOne)
ax.add_patch(secColTwo)
ax.add_patch(secColThree)
ax.add_patch(secColFour)
ax.add_patch(thirdColZero)
ax.add_patch(thirdColOne)
ax.add_patch(thirdColTwo)
ax.add_patch(start_circle)
ax.add_patch(goal_circle)

start_pose = (home_x, home_y, home_theta)
goal_pose = (goal_x, goal_y)

rpm_1= rpm_1 * ((2*np.pi)/60)
rpm_2 = rpm_2 * ((2*np.pi)/60)

start = time.time()
print("\nRRT Implementation\n")

print("\nBe patient!!! I am computing the shortest path!! \n")

action_set = [[0, rpm_1],[rpm_1, 0],[rpm_1, rpm_1],[0, rpm_2],[rpm_2, 0],[rpm_2, rpm_2],[rpm_1, rpm_2],[rpm_2, rpm_1]]

node_in_tree = []

child_parent_graph = {}

goal_reached = False

node_in_tree.append(start_pose)

while not goal_reached:

    goal_found_midway = False

    random_node_generated = genRandomNode()
    random_node_circle = patch.Circle((random_node_generated[0],random_node_generated[1]), 10, linewidth=1, edgecolor='y', facecolor='y')
    goal_circle = patch.Circle((goal_x,goal_y), 20, linewidth=1, edgecolor='r', facecolor='r')
    ax.add_patch(random_node_circle)
    ax.add_patch(goal_circle)

    neighbour_nodes = getClosestNode(random_node_generated)
   
    current_parent = None

    child_graph_value = []

    child_data_near_goal = None

    for temp in neighbour_nodes:

        child_graph_value_loop = []

        current_child_list = []

        rpms_list_loop = []

        current_parent = temp

        if temp in child_parent_graph.keys():            
            worhty_childs = child_parent_graph[current_parent][0]
            rpms_list = child_parent_graph[current_parent][1]            

        else:
            for action in action_set:
                    child_return= child_explored(current_parent, action[0],action[1])
                    
                    if child_return != None:
                        current_child = child_return[0]
                        RPMS_loop = child_return[1]
                        current_child_list.append(current_child)
                        rpms_list_loop.append(RPMS_loop)
                        child_graph_value_loop.append((current_child, RPMS_loop))
                        if check_goal(current_child):
                            goal_found_midway = check_goal(current_child)
                            child_near_goal_found = (current_child, RPMS_loop)
                            child_data_near_goal = child_near_goal_found

            
            if len(current_child_list) != 0:
                current_parent = temp
                worhty_childs = current_child_list
                rpms_list = rpms_list_loop
                child_parent_graph[current_parent] = (worhty_childs, rpms_list)
    
    if not goal_found_midway:
        if len(worhty_childs) != 0:
                
            for c in worhty_childs:
                node_in_tree.append(c)
                
            dist_from_child = []

            for n in worhty_childs:
                dist_from_child.append(dist((random_node_generated[0], random_node_generated[1]), (n[0], n[1])))
            
            new_node_in_tree = worhty_childs[dist_from_child.index(min(dist_from_child))]

            rpms_for_node = rpms_list[dist_from_child.index(min(dist_from_child))]

            if check_goal(new_node_in_tree):
                goal_reached = True
                goal_pose1 = new_node_in_tree
        else:
            continue
    else:

        new_node_in_tree = child_data_near_goal[0]

        rpms_for_node = child_data_near_goal[0]

        goal_reached = True
        goal_pose1 = new_node_in_tree


end = time.time()
print(f'Time needed for the algorithm: {end - start}\n')
print('\n')

check_this = goal_pose1
shortest_path = []
while check_this != start_pose:

    for key, value in child_parent_graph.items():

        if check_this in value[0]:
            action_set_current = value[1][value[0].index(check_this)]
            current_child = check_this
            check_this = key
            shortest_path.append((key, current_child, action_set_current))
            break
shortest_path.reverse()
# print(shortest_path)

with open("./../ros.txt", 'w') as f:
    [f.write(str((item[0][0]/1000)) + ' ' + str((item[0][1]/1000)-1) + '\n') \
     for item in shortest_path]
    
omega_list = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
vel_list = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

for i in range(0,len(shortest_path)):
    t = 0
    r = 33
    L = 160
    dt = 0.1
    Xn= shortest_path[i][0][0]
    Yn= shortest_path[i][0][1]
    # Thetan = 3.14 * current_parent[2] / 180
    Thetan = np.radians(shortest_path[i][0][2])

    UL= shortest_path[i][2][0]
    UR= shortest_path[i][2][1]

    t = 0
    while t<1:
        t = t + dt
        Xs = Xn
        Ys = Yn
        vel_x = 0.5*r * ((UL + UR)) * math.cos(Thetan)
        vel_y = 0.5*r * ((UL + UR)) * math.sin(Thetan)
        Xn = Xn + vel_x * dt
        Yn = Yn + vel_y * dt

        v = ((0.5*r * ((UL + UR)))/1000)
        vel_list.append(v)

        theta_dot = (r / L) * ((UR - UL))
        Thetan += theta_dot * dt

        omega = (theta_dot)

        omega_list.append(omega)

        plt.plot([Xs, Xn], [Ys, Yn], color="orange", linewidth=5)

end_circle = patch.Circle((goal_pose[0], goal_pose[1]), dist((Xn, Yn), goal_pose), linewidth=1, edgecolor='r', facecolor='None')
ax.add_patch(end_circle)        
plt.pause(0.001)

plt.xlabel('X Axis')
plt.ylabel('Y Axis')
plt.title("Visualising Exploration")
plt.axis([0 , 3200 , 0 ,2000])

print(f"The goal is {dist((Xn, Yn), goal_pose)} mm away from last explored node")

plt.show()




